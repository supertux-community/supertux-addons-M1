SuperTux levelset "8+8"

These levels have been created year 2007 by Tarmo Ruusu
when he was 7 years old. They have been created using Supertux
0.1.3 on Fedora Core 5.

They can be freely used in any way. Modified versions must be
identified as such in this README file.
