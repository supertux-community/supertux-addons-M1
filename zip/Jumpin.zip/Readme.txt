Hi,
use the files in which way you want...

some feedback would be nice as well! maxim_lapis@web.de