Arvid & Sylvia's World 2.0

This is the second release of Arvid & Sylvia's Supertux Levels. There are currently three custom level in this package.


Contents:

1. Gratuitous Death - A grisly, ugly level with LOADS of baddies - you gotta figure out the tricks to put 'em under. I find it fun.

2. A Pig, in a Cage, on Antibiotics (with apologies to Radiohead) - A crazy cave level with some jumping. Look out! Unfortunately, there are not any real pigs in Supertux. Sorry.

3. TubeTux - A fast paced level that finds Tux traversing the treacherous tubes of Tierra de la Tortuga in Southern Chile (near Tierra del Fuego). Don't back yourself into a corner, as there is no room to jump in a tube...

Installation for Mac OS X: drag and drop the enclosing folder called "Arvid&Sylvia" into ~/Library/Application Support/Supertux/levels. 

On other systems it should be ~/.supertux/levels, though we have not checked ourselves.

Thanks, enjoy!



Arvid Tomayko-Peters - primary design on 1 and 3
Sylvia Tomayko-Peters - primary design on 2, testing, and all-around expert Supertux player

http://arvidtp.net

arvidtp@earthlink.net

Created on iMac G3 400MHz, Mac OS X 10.3, Supertux 0.1.2

Thanks to CrazyTerabyte for the level editor "breakable blocks" patch that was necessary for the creation of this level ( http://cd.bromley.ac.uk/supertux/forums/viewtopic.php?id=15 ).



These levels are free - you may redistribute them freely, preferably with this Readme file.