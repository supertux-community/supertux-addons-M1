In order to play Bonus Island X levelset, you should do the following:

1) copy the "bonusX" directory in your SuperTux/data/levels directory.
2) copy the "bonusislandX.stwm" in your SuperTux/data/levels/worldmaps directory.

After doing the above, you should find "Bonus Island X" under the Bonus Levels section.