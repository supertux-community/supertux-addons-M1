In order to play Adventure to the new World 3 (ATTNW 3) levelset, you should first make backup copies of the following files in your SuperTux data directory:
 - data/extro.txt,
 - data/intro.txt, and
 - data/levels/worldmaps/world1.stwm.

Next replace these original files with new files with the same names that you can find in this zip file. 
You should also copy the "Adv III", and "IWBTST" directories under your /data/levels directory.

After doing all that, you're able to start ATTNW 3 via "Start Game" in the SuperTux game menu.

In order to play original SuperTux again, just replace the same three files with the original files that you made backup copies of.

P.S
In case you run out of slots for starting a new game, you can delete any saved game under /SuperTux/.supertux/save directory.