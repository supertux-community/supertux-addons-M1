Akeru99's SuperTux Level Set
----------------------
(c) 2008, 2011 by Akeru99

This is free software and it must not be sold.

----------------------
Instalation
----------------------
1. Install SuperTux 0.1.3, which you can get from the official SuperTux website:
   http://supertux.lethargik.org/download.html
   (note that this level set might not work properly with different SuperTux versions)
2. Extract all files from this archive into SuperTux folder.
   (this level set will replace original levels, so be sure to create backup before this step)
3. Run SuperTux, start a new game. Done!